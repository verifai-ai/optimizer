''' Authenticate VERIFAI.AI User Signup and allow access to token:
 The token can be used to access the VERIFAI.AI API...
Class VerifaiAuth() handles signup, signin, and other authorizations for the verifai api
'''
# ==============================================================================
# Copyright 2020 Verifai Inc All Rights Reserved.
#
# ==============================================================================
import glob
import requests
import sys
import os.path
from os import path
from pathlib import Path
import json
import uuid
import pandas as pd
import re
import getpass
import matplotlib.pyplot as plt
from pylab import rcParams
import shutil
import seaborn as sns

VERIFAI_SERVER_URL='http://verifai1.westus.cloudapp.azure.com:9000'

class VerifaiAPI(object):

   def __init__(self, url=VERIFAI_SERVER_URL):
      self.url = url
      self.token = None
      self.username = None

   def read_settings(self):

      ## The file is called ~/.verifai
      conf = None
      home = str(Path.home())
      self.inzfile = home+'/.verifai'
      if path.exists(self.inzfile):
         with open(self.inzfile) as data_file:
            try:
               conf = json.load(data_file)
            except Exception as e:
               print("Error: {0}" .format(str(e)))
               pass
            try:
               self.token = conf['token']
               self.username = conf['user']['username']
            except:
               pass
            return conf
      return None


   def save_settings(self, token, user):

      '''
      Save Token In Users' directory
      The file is called ~/.verifai
      '''
      conf = {}
      home = str(Path.home())
      self.inzfile = home+'/.verifai'
      #if path.exists(self.inzfile):


      conf['token'] = token
      conf['user'] = user
      self.token = token
      self.username = user['username']
      with open(self.inzfile, 'w') as json_file:
         json.dump(conf, json_file)

   def signup_session(self):
      username = input("Please enter a username for VerifAI: ")
      val_email = False
      while not val_email:
          email = input("Please enter a valid email: ")
          val_email = self.check(email)
      pass_match = False

      while not pass_match:
          pswd1 = getpass.getpass("Please Enter your password: ")
          pswd2 = getpass.getpass("Please Re-enter your password: ")
          pass_match = pswd1 == pswd2
          if not pass_match:
              print("Passwords do not match please try again")
      return username, email, pswd1

   def signin_session(self):
      username = input("Please enter your username for VerifAI: ")
      pswd = getpass.getpass("Please Enter your password: ")
      return username,pswd

   def check(self,email):
     # pass the regualar expression
    # and the string in search() method
      regex = '^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$'
      if(re.search(regex,email)):
          return True
      else:
          print("Invalid Email please try again:\n")

   def ask_user_continue(self):
      check = str(input("Do you want to try again ? (Y/N): ")).lower().strip()
      try:
        if check[0] == 'y':
            return True
        elif check[0] == 'n':
            return False
        else:
            print('Invalid Input')
            return self.ask_user_continue()
      except Exception as error:
        print("Please enter valid inputs")
        print(error)
        return self.ask_user_continue()

   def signupsignin(self, username, email = None, password = None):

      if email != None:
         sign = self.url + '/api/v2/auth/signup'
         ## Add your username and password here..
         body = {'username' : username , 'password' : password, 'email' : email }
      else:
         sign = self.url + '/api/v2/auth/signin'
         body = {'username' : username , 'password' : password}

      ## Call the API:
      #print("Connecting to server: {0}" .format(sign))
      x = requests.post(sign , data=body)

      resp =   x.json()
      #print("Response: {0}" .format(resp))
      if 'error' in resp:
         #print("Error: {0}" .format(resp['error']))
         return None
      else:
         user = resp['user']
         if not user:
            print("Error: Received unknown response: {0}" .format(user))
            return None
         try:
            token = resp['token']
            self.save_settings(token,user)
         except Exception as e:
            #print("Couldn't save settings as {}".format(e))
            pass
         return resp
      return None

   def signup(self, username, email, password):

      return(self.signupsignin(username, email = email, password = password))

   def signin(self, username,  password):

      return(self.signupsignin(username, password = password))


   def confirm_signup(self, username, email, inputcode):

      sign = self.url + '/api/v2/auth/confirm-signup'
      ## Add your username and password here..
      body = {'username' : username , 'email' : email, 'inputCode' : inputcode  }

      ## Call the API:
      x = requests.post(sign , data=body)

      resp =   x.json()
      #print("Response: {0}" .format(resp))
      if 'error' in resp:
         print("Error: {0}" .format(resp['error']))
         return None
      else:
         user = resp['user']
         if not user:
            print("Error: Received unknown response: {0}" .format(user))
            return None
         try:
            token = resp['token']
            self.save_settings(token,user)
         except:
            print('error: no token received, please contact hello@verifai.ai')
            return None

         return resp
      return None

   def print_copyright(self):
      print('# ==============================================================================')
      print('# Copyright 2020 Verifai Inc All Rights Reserved.')
      print('#')
      print('# Welcome to Verifai Inc Signup')
      print('# Please signup to get your credentials for access to Verifai API')
      print('# ==============================================================================')


   def check_username_password(self):
      if self.token == None:
         conf = self.read_settings()
         if conf == None or conf == {}:
            print("Error: Could not read token and configuration")
            success = False
            attempt = 1
            while not success and attempt <= 3:
               print("Sign in attempt {}".format(attempt))
               username, pswd = self.signin_session()
               conf = self.signin(username,pswd)
               attempt +=1
               if conf is not None and conf != {}:
                  success = True
                  #resp = self.read_settings()
            if not success:
               print("Incorrect login information: Please contact hello@verifai.ai")
               sys.exit()
         self.token = conf['token']
         self.username = conf['user']['username']


   ## Check Token on Server..

   def check_token(self):

      self.check_username_password()

      db = self.url + '/api/v2/auth/check-token'
      headers = {"Authorization": "Bearer " + self.token}
      #print("request: {0}" .format(db))
      resp = requests.post(db, headers=headers)
      data = resp.json()
      status = False
      message = ''
      
      try:
         if data['status'] == 200:
            status = True
         else:
            status = False
         message = data['message']
      except:
         pass
      
      return (status, message)

   
   ## Get documents from the database

   def get_documents(self, db, collection, outputfilename):

      self.check_username_password()

      db = self.url + '/api/v2/mongo/documents?db='+db+'&collection='+collection
      headers = {"Authorization": "Bearer " + self.token}
      resp = requests.get(db, headers=headers)
      #print("Got Response: {0}" .format(resp))

      data = resp.json()
      with open(outputfilename, 'w') as json_file:
         json.dump(data, json_file)
         print("Saved response in file: {0}" .format(outputfilename))

   ## Run the Optimizer

   def run_optimize(self, config, train_file, niter, incr,output_file):

      self.check_username_password()

      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/reward'
      num_rand_iterations = 1000
      with open(config) as fh:
         mydata = fh.read()
         files = {'configFile' : mydata}


      with open(train_file) as fh:
         mydata = fh.read()
         files.update({'trainingFile' : mydata})
      uid = str(uuid.uuid4())
      incv = 0
      if incr:
         incv = 2

      values = {'config_file' : '/config','uuid' : uid, 'exp' : niter, 'incr' : incv}
      print("Invoking Optimizer: Params: {0}" .format(values))
      values.update(files)

      resp = requests.post(url, data=values,headers=headers)
      data = resp.json()
      print("Output file is {}".format(output_file))

      if output_file.endswith('.json'):
         trainingFile = output_file
      else:
         trainingFile = output_file+'.json'

      if output_file.endswith('.csv'):
         csvFileName =  output_file
      else:
         csvFileName =  output_file +'.csv'

      with open(trainingFile, 'w') as json_file:
         json.dump(data, json_file)
      try:
         df = pd.DataFrame(data['Result'])
      except Exception as e:
         print("Couldn't generate result data as {}".format(e))
         os.remove(self.inzfile)
         sys.exit()
         #print("Df: {0}" .format(df))
      df.to_csv(csvFileName, index=False)
      print("Saved file: {0}" .format(csvFileName))
      return(data)


   ## Import a CSV or JSON file to the database

   def get_importToDb(self, db, collection,filename, filetype='csv'):

      self.check_username_password()

      ## See if we can invoke importToDb
      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/importToDb'

      with open(filename) as fh:
         mydata = fh.read()
         files = {'file' : mydata}
      values = {'db': db, 'collection': collection, 'fileType': filetype,'fileName': filename}
      values.update(files)
      r = requests.post(url, data=values,headers=headers)
      print("Response {0}" .format(r))

   ## Call Build:
   def run_classifier(self, config, train_file):

      self.check_username_password()

      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/build'

      with open(config) as fh:
         mydata = fh.read()
         files = {'configFile' : mydata}

      with open(train_file) as fh:
         mydata = fh.read()
         files.update({'trainingFile' : mydata})

      uid = str(uuid.uuid4())
      values = {'config_file' : "/config",'uuid' : uid}
      values.update(files)
      resp = requests.post(url, data=values,headers=headers)
      data = resp.json()
      print("Response {0}" .format(data))



   
      

   ## Call Analyzer
   def run_analyzer(self, config, train_file):

      self.check_username_password()

      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/analyzeData'

      with open(config) as fh:
         mydata = fh.read()
         files = {'configFile' : mydata}

      with open(train_file) as fh:
         mydata = fh.read()
         files.update({'trainingFile' : mydata})

      uid = str(uuid.uuid4())
      values = {'config_file' : "/config",'uuid' : uid}
      values.update(files)
      resp = requests.post(url, data=values,headers=headers)
      data = resp.json()
      print("Response {0}" .format(data))

   
   def plot_histograms(self,csvfiles=None, config=None,filename=None, column=None, stat = None, rand_iter_list = None, xlabel=None):


      if column == None:
         print("none")
         return False
      list_of_files = []
      #Change output to input for actual vcs run
      if csvfiles != None:
         for csvfile in csvfiles:
            list_of_files.append(csvfile)
      else:
         for csvfile in glob.glob('VERIFAI_RL_FIFO_input*.csv'):
            list_of_files.append(csvfile)
            
      try:
         with open(config) as f:
            conf = json.load(f)
      except:
         print("error: could not open config file {0}" .format(config))
         return False

      try:
         image_dir = conf['Config']['images_dir']
      except:
         print("error: could not open config file {0}" .format(config))
         return False
      datasets = []

      for fl in list_of_files:
         try:
            dataframe = pd.read_csv(fl,
                                    compression='infer', index_col=False)
            dataframe['reward_column'] = dataframe[column].mean(axis = 1)
            dataframe.dropna(inplace=True)
            datasets.append(dataframe)

         except:
            print("error: could not read datafile {0}" .format(fl))
            pass
      try:
          shutil.rmtree(conf_data["Config"]["images_dir"])
      except:
          print("No existing image directory")

      # Setup Plot
      sns.set_context("poster", rc={"font.size":15,"axes.titlesize":15,"axes.labelsize":15})


      fig, axs = plt.subplots(len(datasets), figsize=(12,24))
      #sns.despine(left=True)
      nplots = len(datasets)
      for i,v in enumerate(range(nplots)):
         v = v+1
         print('iteration list {0}' .format(v-1))
         ax1 = plt.subplot(nplots,1,v)
         ax1.set(ylabel='occurrence', xlabel=(xlabel if xlabel else ''), title = "{} iterations".format(rand_iter_list[v-1]))
         #sns.distplot(datasets[i]['reward_column'], ax = ax1)
         ax1.hist(datasets[i]['reward_column'])

      # If directory doesn't exist: create one..
      #fig.savefig(image_dir+"/combined.png")
      fig.tight_layout()
      fig.savefig(filename)
      print("------Saved results are in: {0}" .format(filename))
      #fig.savefig(os.path.join(image_dir,filename))



      
   ## Call pd_predict
   '''
   1. Call to train model: verifai pd_predict -c fiveclf.json
   2. Call to predict_only verifai pd_predict -pb sldpc_top -s PlaceOptDesign_Enc -n CTSynthesis_Enc -c fiveclf.json -pd predict.csv
   '''
   def run_pd_predict(self, config, block=None, step=None, next_step=None, predict_file=None, rundir=None, mongourl=None, output_file=None):

      self.check_username_password()

      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/pd_predict'

      with open(config) as fh:
         mydata = fh.read()
         files = {'configFile' : mydata}

      uid = str(uuid.uuid4())
      values = {'uuid' : uid}
      if predict_file != None:
         with open(predict_file) as fh:
            mydata = fh.read()
            files.update({'predictFile' : mydata})
         values.update({'block' : block, 'step' : step, 'next_step' : next_step, 'rundir' : rundir, 'mongourl' : mongourl, 'output_file' : output_file})

      if rundir != None and mongourl != None:
         values.update({'block' : block, 'step' : step, 'next_step' : next_step, 'rundir' : rundir, 'mongourl' : mongourl, 'output_file' : output_file})
         
      values.update(files)
      print("Headers : {0}" .format(headers))
      resp = requests.post(url, data=values,headers=headers)
      data = resp.json()
      return data

