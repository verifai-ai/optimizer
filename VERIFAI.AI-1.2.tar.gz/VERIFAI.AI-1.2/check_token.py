
''' Authenticate VERIFAI.AI User Signup and allow access to token:
 The token can be used to access the VERIFAI.AI API...
Class VerifaiAuth() handles signup, signin, and other authorizations for the verifai api
'''
# ==============================================================================
# Copyright 2020 Verifai Inc All Rights Reserved.
#
# ==============================================================================

import requests
import sys
import os.path
from os import path
from pathlib import Path
import json
import uuid
import pandas as pd
import re
import getpass
from VerifaiAPI import *
import argparse

VERIFAI_LOCAL_URL='http://localhost:9000'



import sys
import time
from  VerifaiCheck import *

def spinning_cursor():
    while True:
        for cursor in '|/-\\':
            yield cursor


def main(args1):


    parser = argparse.ArgumentParser()


    parser.add_argument("-url", "--url", dest="url", default=VERIFAI_SERVER_URL,
                        help="Specify a VerifAI URL Server to connect with (Default=http://localhost:9000)", metavar="STRING")
    args, unknown = parser.parse_known_args(args1)




    status, message = VerifaiCheckToken()

    print("Status: {0}  Message: {1}" .format(status, message))



if __name__ == "__main__":
    import sys
    main(sys.argv[1:])
