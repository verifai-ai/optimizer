''' Authenticate VERIFAI.AI User Signup and allow access to token:
 The token can be used to access the VERIFAI.AI API...
Class VerifaiAuth() handles signup, signin, and other authorizations for the verifai api
'''
# ==============================================================================
# Copyright 2020 Verifai Inc All Rights Reserved.
#
# ==============================================================================

import requests
import sys
import os.path
from os import path
from pathlib import Path
import json
import uuid
import pandas as pd
import re
import getpass

VERIFAI_SERVER_URL='http://40.78.15.68:9000'

class VerifaiAPI(object):

   def __init__(self, url=VERIFAI_SERVER_URL):
      self.url = url
      self.token = None
      self.username = None

   def read_settings(self):

      ## The file is called ~/.verifai
      conf = None
      home = str(Path.home())
      self.inzfile = home+'/.verifai'
      if path.exists(self.inzfile):
         with open(self.inzfile) as data_file:
            try:
               conf = json.load(data_file)
            except Exception as e:
               print("Error: {0}" .format(str(e)))
               pass
            try:
               self.token = conf['token']
               self.username = conf['user']['username']
            except:
               pass
            return conf
      return None


   def save_settings(self, token, user):

      '''
      Save Token In Users' directory
      The file is called ~/.verifai
      '''
      conf = {}
      home = str(Path.home())
      self.inzfile = home+'/.verifai'
      #if path.exists(self.inzfile):


      conf['token'] = token
      conf['user'] = user
      self.token = token
      self.username = user['username']
      with open(self.inzfile, 'w') as json_file:
         json.dump(conf, json_file)

   def signup_session(self):
      username = input("Please enter a username: ")
      val_email = False
      while not val_email:
          email = input("Please enter a valid email: ")
          val_email = self.check(email)
      pass_match = False

      while not pass_match:
          pswd1 = getpass.getpass("Please Enter your password: ")
          pswd2 = getpass.getpass("Please Re-enter your password: ")
          pass_match = pswd1 == pswd2
          if not pass_match:
              print("Passwords do not match please try again")
      return username, email, pswd1

   def signin_session(self):
      username = input("Please enter your username: ")
      pswd = getpass.getpass("Please Enter your password: ")
      return username,pswd

   def check(self,email):
     # pass the regualar expression
    # and the string in search() method
      regex = '^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$'
      if(re.search(regex,email)):
          return True
      else:
          print("Invalid Email please try again:\n")

   def ask_user_continue(self):
      check = str(input("Do you want to try again ? (Y/N): ")).lower().strip()
      try:
        if check[0] == 'y':
            return True
        elif check[0] == 'n':
            return False
        else:
            print('Invalid Input')
            return self.ask_user_continue()
      except Exception as error:
        print("Please enter valid inputs")
        print(error)
        return self.ask_user_continue()

   def signupsignin(self, username, email = None, password = None):

      if email != None:
         sign = self.url + '/api/v2/auth/signup'
         ## Add your username and password here..
         body = {'username' : username , 'password' : password, 'email' : email }
      else:
         sign = self.url + '/api/v2/auth/signin'
         body = {'username' : username , 'password' : password}

      ## Call the API:
      #print("Connecting to server: {0}" .format(sign))
      x = requests.post(sign , data=body)

      resp =   x.json()
      #print("Response: {0}" .format(resp))
      if 'error' in resp:
         #print("Error: {0}" .format(resp['error']))
         return None
      else:
         user = resp['user']
         if not user:
            print("Error: Received unknown response: {0}" .format(user))
            return None
         try:
            token = resp['token']
            self.save_settings(token,user)
         except Exception as e:
            #print("Couldn't save settings as {}".format(e))
            pass
         return resp
      return None

   def signup(self, username, email, password):

      return(self.signupsignin(username, email = email, password = password))

   def signin(self, username,  password):

      return(self.signupsignin(username, password = password))


   def confirm_signup(self, username, email, inputcode):

      sign = self.url + '/api/v2/auth/confirm-signup'
      ## Add your username and password here..
      body = {'username' : username , 'email' : email, 'inputCode' : inputcode  }

      ## Call the API:
      x = requests.post(sign , data=body)

      resp =   x.json()
      #print("Response: {0}" .format(resp))
      if 'error' in resp:
         print("Error: {0}" .format(resp['error']))
         return None
      else:
         user = resp['user']
         if not user:
            print("Error: Received unknown response: {0}" .format(user))
            return None
         try:
            token = resp['token']
            self.save_settings(token,user)
         except:
            print('error: no token received, please contact hello@verifai.ai')
            return None

         return resp
      return None

   def print_copyright(self):
      print('# ==============================================================================')
      print('# Copyright 2020 Verifai Inc All Rights Reserved.')
      print('#')
      print('# Welcome to Verifai Inc Signup')
      print('# Please signup to get your credentials for access to Verifai API')
      print('# ==============================================================================')


   def check_username_password(self):
      if self.token == None:
         conf = self.read_settings()
         if conf == None or conf == {}:
            print("Error: Could not read token and configuration")
            success = False
            attempt = 1
            while not success and attempt <= 3:
               print("Sign in attempt {}".format(attempt))
               username, pswd = self.signin_session()
               conf = self.signin(username,pswd)
               attempt +=1
               if conf is not None and conf != {}:
                  success = True
                  #resp = self.read_settings()
            if not success:
               print("Incorrect login information:")
               sys.exit()
         self.token = conf['token']
         self.username = conf['user']['username']



   ## Get documents from the database

   def get_documents(self, db, collection, outputfilename):

      self.check_username_password()

      db = self.url + '/api/v2/mongo/documents?db='+db+'&collection='+collection
      headers = {"Authorization": "Bearer " + self.token}
      resp = requests.get(db, headers=headers)
      #print("Got Response: {0}" .format(resp))

      data = resp.json()
      with open(outputfilename, 'w') as json_file:
         json.dump(data, json_file)
         print("Saved response in file: {0}" .format(outputfilename))

   ## Run the Optimizer
         
   def run_optimize(self, config, train_file, niter, incr,output_file):

      self.check_username_password()
      
      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/reward'
      num_rand_iterations = 1000
      for num_iter in range(niter):
         with open(config) as fh:
            mydata = fh.read()
            files = {'configFile' : mydata}
            #print("config is {}".format(mydata))
         print("Iteration {0} : CSV {1}" .format(num_iter, train_file))
         with open(train_file) as fh:
            mydata = fh.read()
            files.update({'trainingFile' : mydata})
         uid = str(uuid.uuid4())
         values = {'config_file' : '/config','uuid' : uid, 'exp' : num_iter , 'num_rand_iterations' : num_rand_iterations, 'incr' : incr}
         values.update(files)
         resp = requests.post(url, data=values,headers=headers)
         data = resp.json()
         print("Output file is {}".format(output_file))
         trainingFile = output_file+str(num_iter)+'.json'
         csvFileName =  output_file +str(num_iter)+'.csv'
         with open(trainingFile, 'w') as json_file:
            json.dump(data, json_file)
         try:
            df = pd.DataFrame(data['Result'])
         except Exception as e:
            print("Couldn't generate result data as {}".format(e))
            os.remove(self.inzfile)
            sys.exit()
         #print("Df: {0}" .format(df))
         df.to_csv(csvFileName)
         print("Saved file: {0}" .format(csvFileName))
         num_rand_iterations *= 10


   ## Import a CSV or JSON file to the database
         
   def get_importToDb(self, db, collection,filename, filetype='csv'):

      self.check_username_password()
      
      ## See if we can invoke importToDb
      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/importToDb'

      with open(filename) as fh:
         mydata = fh.read()
         files = {'file' : mydata}
      values = {'db': db, 'collection': collection, 'fileType': filetype,'fileName': filename}
      values.update(files)
      r = requests.post(url, data=values,headers=headers)
      print("Response {0}" .format(r))

   ## Call Build:
   def run_classifier(self, config, train_file):

      self.check_username_password()
      
      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/build'

      with open(config) as fh:
         mydata = fh.read()
         files = {'configFile' : mydata}

      with open(train_file) as fh:
         mydata = fh.read()
         files.update({'trainingFile' : mydata})

      uid = str(uuid.uuid4())
      values = {'config_file' : "/config",'uuid' : uid}
      values.update(files)
      resp = requests.post(url, data=values,headers=headers)
      data = resp.json()
      print("Response {0}" .format(data))



   ## Call Analyzer
   def run_analyzer(self, config, train_file):

      self.check_username_password()
      
      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/analyzeData'

      with open(config) as fh:
         mydata = fh.read()
         files = {'configFile' : mydata}

      with open(train_file) as fh:
         mydata = fh.read()
         files.update({'trainingFile' : mydata})

      uid = str(uuid.uuid4())
      values = {'config_file' : "/config",'uuid' : uid}
      values.update(files)
      resp = requests.post(url, data=values,headers=headers)
      data = resp.json()
      print("Response {0}" .format(data))


      
