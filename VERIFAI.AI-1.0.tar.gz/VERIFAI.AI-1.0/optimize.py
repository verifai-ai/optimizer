
''' Authenticate VERIFAI.AI User Signup and allow access to token:
 The token can be used to access the VERIFAI.AI API...
Class VerifaiAuth() handles signup, signin, and other authorizations for the verifai api
'''
# ==============================================================================
# Copyright 2020 Verifai Inc All Rights Reserved.
#
# ==============================================================================

import requests
import sys
import os.path
from os import path
from pathlib import Path
import json
import uuid
import pandas as pd
import re
import getpass
from VerifaiAPI import *
import argparse

VERIFAI_LOCAL_URL='http://localhost:9000'



import sys
import time

def spinning_cursor():
    while True:
        for cursor in '|/-\\':
            yield cursor


def main(args1):


    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", dest="config_file",
                        help="Path to config filename", metavar="STRING")

    parser.add_argument("-tr", "--training_data", dest="training_data",
                        help="Path to input training-data", metavar="STRING")

    parser.add_argument("-iter", "--iterations", dest="n_iterations",
                        help="Number of iteratons to run from Sim --> Optimizer --> Sim")

    parser.add_argument("-o", "--output_file", dest="output_file", default="opt.output",
                        help="Specify an output file to write the results (Default=output.knobs.csv)", metavar="STRING")
    parser.add_argument("-incr","--incremental",action="store_true", dest="incremental", help = "Run reward_predictor in incremental mode")

    parser.add_argument("-url", "--url", dest="url", default=VERIFAI_SERVER_URL,
                        help="Specify a VerifAI URL Server to connect with (Default=http://localhost:9000)", metavar="STRING")
    args, unknown = parser.parse_known_args(args1)
    if not args.config_file:
        print("Please specify a config file")
        sys.exit(0)

    if args.config_file:
        conf_file = args.config_file
    elif args.folder_name:
        conf_file = args.folder_name + '/config.json'
    else:
        print("Please specify a config file")
        sys.exit(0)
    if not args.training_data:
        print("Please specify a training data file in csv format")
        sys.exit(0)
    train_file = args.training_data
    if args.n_iterations:
        niter = int(args.n_iterations)
    else:
        niter = 1

    if args.incremental:
        incr = args.incremental
    else:
        incr = False

    if args.output_file:
        output_file = args.output_file
    else:
        output_file = 'opt.output'

    auth = VerifaiAPI(url=args.url)

    spinner = spinning_cursor()
    for _ in range(50):
        sys.stdout.write(next(spinner))
        sys.stdout.flush()
        time.sleep(0.1)
        sys.stdout.write('\b')
    resp1 = auth.run_optimize(conf_file, train_file,niter,incr,output_file)
    with open(conf_file) as f:
        conf_data = json.load(f)
    #print("Response: {0}" .format(resp1))
    auth.plot_histograms(csvfiles=["FIFO_knobs.csv",output_file+".csv"],config=conf_file,filename = "combined_histogram.png",
                         column=conf_data['Config']['RewardPredictor']['reward_column'],
                         stat = conf_data['Config']['RewardPredictor']['reward_stat'],
                         rand_iter_list = ["1","2"], xlabel="Avg FIFO Depth")


if __name__ == "__main__":
    import sys
    main(sys.argv[1:])
