# ==============================================================================
# Copyright 2020 VERIFAI Inc All Rights Reserved.
#
# ==============================================================================
'''
#-----------------------------------------------------------------------
#Version: 1.0
#Author(s): Maithilee Kulkarni , Rohit Suvarna, Sandeep Srinivasan
file: run_sims.py
purpose: a script that runs the VerifAI optimizer on the FIFO cache controller example:
'''
import sys,os

try:
    if os.environ['INZONE_HOME']:
        sys.path.append(os.path.join(os.path.dirname(__file__), os.environ['INZONE_HOME']+"/python"))
        sys.path.append(os.path.join(os.path.dirname(__file__), os.environ['INZONE_HOME']+"/python/scripts"))
except:
    pass
sys.path.append(os.path.join(os.path.dirname(__file__), "../../"))
sys.path.append(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(os.path.join(os.path.dirname(__file__), "../bin/"))

import pandas as pd
import numpy as np
import re
import datetime as dt
import subprocess
import shlex
'''
Import INZONE packages
'''
#from inzone import *
#from inzoneai.dataset import DataSet
import copy
import re
import datetime as dt
import re
import datetime as dt
import numpy as np
from scipy import stats
import collections
import csv
#import run_optimizer
import argparse
import json
from VerifaiAPI import *

def generate_traininig_data(infile , outfile, row, cols, nsims):
#-----------------------------------------------------------------------
#This is for generating training data for the RL/DNN/DQN
#Author: Sandeep Srinivasan
#-----------------------------------------------------------------------
    #infile = "cov_per_config.txt"
    #outfile = "train_data.csv"


    reset = 0;
    # If First Sim: Create a new file for this
    if nsims == 1:
        with open(outfile, "w") as f:
            writer = csv.writer(f)
            writer.writerows([cols])
    else:
        with open(outfile, "a") as f:
            writer = csv.writer(f)


    # Write Fifo Depths
    f_mean = [None] * 4
    f_median =  [None] * 4
    f_mode =  [None] * 4
    f_max =  [None] * 4
    f_mfreq =  [None] * 4
    with open(infile) as in1:
        for line in in1:
            if (line.find("fifo_0") != -1) :
                fields = line.split(',')
                f_mean[0]  = fields[1]
                row['mean_fifo_depth_0'] = f_mean[0]
                f_median[0]  = fields[2]
                f_mode[0]  = fields[3]
                f_max[0]  = fields[4]
                f_mfreq[0]  = fields[5]
            elif (line.find("fifo_1") != -1) :
                fields = line.split(',')
                f_mean[1]  = fields[1]
                row['mean_fifo_depth_1'] = f_mean[1]
                f_median[1]  = fields[2]
                f_mode[1]  = fields[3]
                f_max[1]  = fields[4]
                f_mfreq[1]  = fields[5]

            elif (line.find("fifo_2") != -1) :
                fields = line.split(',')
                f_mean[2]  = fields[1]
                row['mean_fifo_depth_2'] = f_mean[2]
                f_median[2]  = fields[2]
                f_mode[2]  = fields[3]
                f_max[2]  = fields[4]
                f_mfreq[2]  = fields[5]
            elif (line.find("fifo_3") != -1) :
                fields = line.split(',')
                f_mean[3]  = fields[1]
                row['mean_fifo_depth_3'] = f_mean[3]
                f_median[3]  = fields[2]
                f_mode[3]  = fields[3]
                f_max[3]  = fields[4]
                f_mfreq[3]  = fields[5]
            else:
                pass

    # write the row
    print("---------- FIFO Depths for Sim#{0} = {1}" .format(nsims, f_mean))
    fullrow =   list(row.values)
    # Now write fifo depths
    with open(outfile, "a") as f:
        writer = csv.writer(f)
        writer.writerows([fullrow])

def parse_vcd(infile, outfile):
#-----------------------------------------------------------------------
#This is for parsing vcd_parser.py to get fifo_depth
#Date: 27th Nov, 2018
#Version: 1.0
#Author: Maithilee Kulkarni
#-----------------------------------------------------------------------



    #infile = "mesi_isc.vcd"
    #outfile = "cov_per_config.txt"

    out1 = open(outfile, "w")
    reset = 0;

    with open(infile) as in1:
        for line in in1:
            if (line.find("fifo_3") != -1) :
                for line in in1 :
                    if(line.find("$upscope $end") != -1):
                        break
                    else:
                        if(line.find("fifo_depth [3:0]") != -1):
                            contents = line.split(' ')
                            fifo_3_symbol = contents[3]
					#print("fifo_3_symbol   "+fifo_3_symbol)
            elif (line.find("fifo_2") != -1) :
                for line in in1 :
                    if(line.find("$upscope $end") != -1):
                        break
                    else:
                        if(line.find("fifo_depth [3:0]") != -1):
                            contents = line.split(' ')
                            fifo_2_symbol = contents[3]
					#print("fifo_2_symbol   "+fifo_2_symbol)
            elif (line.find("fifo_1") != -1) :
                for line in in1 :
                    if(line.find("$upscope $end") != -1):
                        break
                    else:
                        if(line.find("fifo_depth [3:0]") != -1):
                            contents = line.split(' ')
                            fifo_1_symbol = contents[3]
					#print("fifo_1_symbol   "+fifo_1_symbol)
            elif (line.find("fifo_0") != -1) :
                for line in in1 :
                    if(line.find("$upscope $end") != -1):
                        break
                    else:
                        if(line.find("fifo_depth [3:0]") != -1):
                            contents = line.split(' ')
                            fifo_0_symbol = contents[3]
					#print("fifo_0_symbol   "+fifo_0_symbol)

#-----------------------------------------------------------------------------------------
    lst3=[]
    with open(infile) as in1:
        for line in in1:
            if (line.find(fifo_3_symbol) != -1) :
                contents=line.split(' ')
                contents[1] = contents[1].strip()
                fifo_3_symbol = fifo_3_symbol.strip()
                if(fifo_3_symbol in contents[1] and "b" in contents[0]) :
                    contents[0] = contents[0].lstrip("b")
                    contents[0] = int(contents[0],2)
                    lst3.append(contents[0])

    mean= np.mean(lst3)
    median = np.median(lst3)
    mode = stats.mode(lst3)
    max_= max(lst3)
    mfreq=0

    for max_ in lst3[:]:
        mfreq=mfreq+1

    out1.write("fifo_3,  "+str(mean)+",  "+str(median)+",  "+str(mode[0]).strip('[].')+",  "+str(max_)+",  "+str(mfreq))


#-----------------------------------------------------------------------------------------
    lst2=[]
    with open(infile) as in1:
        for line in in1:
            if (line.find(" "+fifo_2_symbol) != -1) :
		#print(line)
                contents=line.split(' ')
                fifo_2_symbol = fifo_2_symbol.strip()
                if(fifo_2_symbol in contents[1] and "b" in contents[0]) :
			#print("true")
                    contents[0] = contents[0].lstrip("b")
                    contents[0] = int(contents[0],2)
                    lst2.append(contents[0])

    mean= np.mean(lst2)
    median = np.median(lst2)
    mode = stats.mode(lst2)
    max_= max(lst2)
    mfreq=0

    for max_ in lst2[:]:
        mfreq=mfreq+1

    out1.write("\nfifo_2,  "+str(mean)+",  "+str(median)+",  "+str(mode[0]).strip('[].')+",  "+str(max_)+",  "+str(mfreq))

#-----------------------------------------------------------------------------------------
    lst1=[]
    with open(infile) as in1:
        for line in in1:
            if (line.find(" "+fifo_1_symbol) != -1) :
		#print(line)
                contents=line.split(' ')
                fifo_1_symbol = fifo_1_symbol.strip()
                if(fifo_1_symbol in contents[1] and "b" in contents[0]) :
			#print("true")
                    contents[0] = contents[0].lstrip("b")
                    contents[0] = int(contents[0],2)
                    lst1.append(contents[0])

    mean= np.mean(lst1)
    median = np.median(lst1)
    mode = stats.mode(lst1)
    max_= max(lst1)
    mfreq=0

    for max_ in lst1[:]:
        mfreq=mfreq+1

    out1.write("\nfifo_1,  "+str(mean)+",  "+str(median)+",  "+str(mode[0]).strip('[].')+",  "+str(max_)+",  "+str(mfreq))


#-----------------------------------------------------------------------------------------
    lst0=[]
    with open(infile) as in1:
        for line in in1:
            if (line.find(" "+fifo_0_symbol) != -1) :
		#print(line)
                contents=line.split(' ')
                fifo_0_symbol = fifo_0_symbol.strip()
                if(fifo_0_symbol in contents[1] and "b" in contents[0]) :
			#print("true")
                    contents[0] = contents[0].lstrip("b")
                    contents[0] = int(contents[0],2)
                    lst0.append(contents[0])

    mean= np.mean(lst0)
    median = np.median(lst0)
    mode = stats.mode(lst0)
    max_= max(lst0)
    mfreq=0

    for max_ in lst0[:]:
        mfreq=mfreq+1

    out1.write("\nfifo_0,  "+str(mean)+",  "+str(median)+",  "+str(mode[0]).strip('[].')+",  "+str(max_)+",  "+str(mfreq))
    out1.close()



def generate_sequences_parser(infile, outfile):
    #infile = "generated_sequences.txt"
    #outfile = "testbench.sv"

    out1 = open(outfile, "w")
    reset = 0;

    out1.write("// -----------------------------------------------------------------------\n")
    out1.write("// This is automatically generated by generated_sequences_parser.py\n")
    out1.write("// -----------------------------------------------------------------------\n\n")


    out1.write("`include \"constraints_define.sv\"\n\n")
    out1.write("module top;\n\n")

    out1.write("parameter");
    out1.write("  MBUS_CMD_WIDTH           = 3,\n")
    out1.write("  ADDR_WIDTH               = 32,\n")
    out1.write("  BROAD_TYPE_WIDTH         = 2,\n")
    out1.write("  BROAD_ID_WIDTH           = 7,\n")
    out1.write("  BREQ_FIFO_SIZE           = 16,\n")
    out1.write("  BREQ_FIFO_SIZE_LOG2      = 4;\n\n")

    out1.write("reg                   clk;\n")
    out1.write("reg                   rst;\n")
    out1.write("reg [4*MBUS_CMD_WIDTH-1:0] mbus_cmd_array_i;\n ")
    out1.write("reg [4*ADDR_WIDTH-1:0] mbus_addr_array_i;\n")

    out1.write("reg                    broad_fifo_status_full_i;\n\n")


    out1.write("wire [3:0]             mbus_ack_array_o;\n")
    out1.write("wire                   broad_fifo_wr_o;\n")
    out1.write("wire [ADDR_WIDTH-1:0]  broad_addr_o;\n")
    out1.write("wire [BROAD_TYPE_WIDTH-1:0] broad_type_o;\n")
    out1.write("wire [1:0]             broad_cpu_id_o;\n")
    out1.write("wire [BROAD_ID_WIDTH-1:0] broad_id_o;\n\n")

    out1.write("mesi_isc_breq_fifos mesi_isc_breq_fifos1 (clk,\n")
    out1.write("     rst,\n")
    out1.write("     mbus_cmd_array_i,\n")
    out1.write("     mbus_addr_array_i,\n")
    out1.write("     broad_fifo_status_full_i,\n")
    out1.write("     mbus_ack_array_o,\n")
    out1.write("     broad_fifo_wr_o,\n")
    out1.write("     broad_addr_o,\n")
    out1.write("     broad_type_o,\n")
    out1.write("     broad_cpu_id_o,\n")
    out1.write("     broad_id_o);\n\n")

    out1.write("   initial\n")
    out1.write("      begin\n")
    out1.write("		clk = 0;\n")
    out1.write("		rst = 1;\n")
    out1.write("		#20 rst = 0;\n")
    out1.write("		broad_fifo_status_full_i = 0;\n")

    with open(infile) as in1:
        for line in in1:
            if (line.find("Compiler version") != -1) :
                for line in in1 :
                    if(line.find("V C S   S i m u l a t i o n   R e p o r t") != -1):
                        break
                    else:
                        out1.write("		"+line)

    out1.write("      end\n\n")

    out1.write("   // Run simulation for 15 ns.\n")
    out1.write("   initial #15000 $finish;\n\n")

    out1.write("   // Dump all waveforms to d_latch.dump\n")
    out1.write("   initial\n")
    out1.write("   begin\n")
    out1.write("        $dumpfile (\"mesi_isc.vcd\");\n")
    out1.write("        $dumpvars (0, top);\n")
    out1.write("   end // initial begin\n\n")

    out1.write("	always \n")
    out1.write("	    #5 clk = !clk;\n")

    out1.write("endmodule\n")




def input_knobs_to_constraints(infile,outfile):
    date = dt.datetime.today().strftime("%m/%d/%Y")

    tag_range = { 0 : 0x0001, 1 : 0x0002, 2 : 0x0004, 3 : 0x0008, 4 : 0x000F, 5 : 0x00FF, 6 : 0x0FFF, 7 : 0xFFFF}
    index_range = { 0 : 0x001, 1 : 0x001, 2 : 0x002, 3 : 0x004, 4 : 0x008, 5 : 0x00F, 6 : 0x0FF, 7 : 0xFFF}
    offset_range = { 0 : 0x1, 1 : 0x1, 2 : 0x2, 3 : 0x4, 4 : 0x8, 5 : 0xA, 6 : 0xC, 7 : 0xF}

    #infile = "input_knobs.txt"
    #outfile = "constraints_define.sv"

    out1 = open(outfile, "w")
    reset = 0;

    out1.write("// -----------------------------------------------------------------------\n")
    out1.write("// This is automatically generated by input_knobs_to_constraints.py\n")
    out1.write("// Date: " + date + "\n")
    out1.write("// -----------------------------------------------------------------------\n\n")


    out1.write("`timescale 1ns / 1ps \n\n")

    with open(infile) as in1:
        for line in in1:
            if (line.find("//") == -1 and len(line.strip()) >= 1) :
                contents = re.split("=",line)
                if len(contents) == 1:
                    #print("content {0}" .format(contents))
                    continue
                #print("OK:content {0}" .format(contents))
                contents[1] = contents[1].lstrip()
                contents[1] = contents[1].strip()
                #contents[1] = re.findall("\d+\.\d+",contents[1])[0]
                contents[1] = re.sub("\D","",contents[1])
                #print("1: contents[1] {0}" .format(contents[1]))
                if (contents[0].find("range") == -1) :
                    contents[1] = int(float(contents[1]))
                    contents[1] = hex(contents[1])
                    temp = "`define "+ contents[0]+ "'h" + str(contents[1]).strip("0x") + "\n"
                    out1.write(temp)
		#print(temp)
                elif (contents[0].find("tag") != -1) :
                    contents[1] = int(float(contents[1]))
                    #contents[1] = hex(contents[1])
                    temp2 = tag_range[contents[1]]
                    #print("tag Range {0}  Val: {1}  Hex: {2}" .format(tag_range, temp2, hex(temp2)))
                    temp2 = hex(temp2)
                    temp = "`define "+ contents[0]+ "'h" + str(temp2).strip("0x") + "\n"
                    out1.write(temp)
			#print (temp)
                elif (contents[0].find("offset") != -1) :
                    contents[1] = int(float(contents[1]))
                    temp2 = offset_range[contents[1]]
                    temp2 = hex(temp2)
                    temp = "`define "+ contents[0]+ "'h" + str(temp2).strip("0x") + "\n"
                    out1.write(temp)
			#print (temp)
                elif (contents[0].find("index") != -1) :
                    contents[1] = int(float(contents[1]))
                    temp2 = index_range[contents[1]]
                    temp2 = hex(temp2)
                    temp = "`define "+ contents[0]+ "'h" + str(temp2).strip("0x") + "\n"
                    out1.write(temp)
			#print (temp)
                else :
                    print ("Caught here\n")

    out1.close()


def main(unused_argv):

    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", dest="config_file",
                        help="Path to config filename", metavar="STRING")

    parser.add_argument("-ir", "--initial_random", dest="initial_random", help="Initial Randomized knobs for the simulator",
                         metavar="STRING")

    parser.add_argument("-iter", "--iterations", dest="n_iterations",
                        help="Number of iteratons to run from Sim --> Optimizer --> Sim")

    parser.add_argument("-force","--force",action="store_true", dest="force", help = "Run reward_predictor in non-incremental mode, force a fresh model")
    parser.add_argument("-debug","--debug",action="store_true", dest="debug", help = "Run in debug mode, run all steps except Sim")
    parser.add_argument("-o", "--output_file", dest="output_file", default="opt.output.",
                        help="Specify an output file to write the results (Default=output.knobs.csv)", metavar="STRING")

    parser.add_argument("-url", "--url", dest="url", default=VERIFAI_SERVER_URL,
                        help="Specify a VerifAI URL Server to connect with (Default=http://localhost:9000)", metavar="STRING")

    args, unknown = parser.parse_known_args()


    # Default Global : number of iterations = 1
    if args.n_iterations:
        niter = int(args.n_iterations)
    else:
        niter = 1

    if not args.config_file:
        print("Please specify a config file")
        sys.exit(0)
    if not args.initial_random:
        print("Please specify an initial random settings for the simulator")
        sys.exit(0)

    if args.force:
        incr = False
    else:
        incr = True


    if args.output_file:
        output_file = args.output_file
    else:
        output_file = 'opt.output.'

    # This gets set in the loop, next training_data is generated by the run_optimizer() command
    # iterate-over: training_data -->> SIM -->> run_optimizer -->> training_data
    training_data = args.initial_random
    num_rand_iterations = 1000
    rand_iter_list = [num_rand_iterations]
    for num_iter in range(niter):
    #df = DataFrame2()
        try:
            print("Reading {0}" .format(training_data))
            dataframe = pd.read_csv(training_data,
                                    compression='infer', index_col=False)
        except Exception as e:
            print("Unable to read initial random file {0}" .format(args.initial_random))
            sys.exit(0)

        #config = Config()
        conf_file = args.config_file

        with open(conf_file) as f:
            conf_data = json.load(f)

        # Default Names and values from config
        input_knobs_file = "input_knobs.txt"
        constraints_define_file = "constraints_define.sv"
        try:
            experiment_name = conf_data['Config']['RewardPredictor']['experiment_type']
        except:
            experiment_name = "TEST"

        try:
            num_rand_iterations = conf_data["Config"]["RewardPredictor"]["num_rand_iterations"]
            print("Using iterations {0}" .format(num_rand_iterations))
        except:
            print("Using default value of num rand iterations")
            num_rand_iterations = 1000

        cols =  list(dataframe.columns.values)
        print("shape of data: {0} " .format(dataframe.shape))

	#--------------------------- random_knobs.csv -->> Generate -->> input knobs.txt-------------------------#
        nsims=0

        for index, row in dataframe.iterrows():
        #print("index: {0}" .format(index))
            fd = open("input_knobs.txt","w")
            for col in cols:
                if  not pd.isna(row[col]):
                #print(col + " = " + str(int(row[col])) + " ;")
                    fd.write(col + " = " + str(int(row[col])) + " ;\n")

        #--------------------------- input knobs.txt ->> Generate -->>  constraints_define.sv-------------------------#
            fd.close()
            nsims += 1
            print("Processing Input Knobs")
            input_knobs_to_constraints(input_knobs_file, constraints_define_file)

        #--------------------------- constraints_define.sv and sequences.sv to get generated_sequences.txt-------------------------#
            cmd ="vcs -full64 -sverilog constraints_define.sv sequences.sv -debug"
            p = os.system(cmd)
            print("done step: {0}" .format(p))
            f = open("generated_sequences.txt", "w")
            p = subprocess.run(["./simv"],shell=True,stdout=f)
            print("done step: {0}" .format(p))


        #--------------------------- generated_sequences.txt and generated_sequences_parser.py to get testbench.sv -------------------------#
            generate_sequences_parser(infile="generated_sequences.txt", outfile="testbench.sv")


        #--------------------------- run master (RTL + testbench.sv + defines) -------------------------#
            cmd ="vcs -full64 -f master.vcs -debug"
            p = os.system(cmd)
            print("done step: {0}" .format(p))

            p = subprocess.run(["./simv"], shell=True,stdout=subprocess.PIPE)
            print("done step: {0}" .format(p))

	#--------------------------- parse VCD generated to get cov_per_config.txt -------------------------#
            cov_file = experiment_name + ".cov_per_config.txt"
            parse_vcd(infile = "mesi_isc.vcd",outfile = cov_file)
            print("------- done parsing VCD ----------")

        #--------------------------- generate report (train_data)-------------------------#
            train_file = '_'.join(["VERIFAI_RL","FIFO","input",str(num_iter+1)]) +".csv"
            print("-------appending to training data file {0}--------" .format(train_file))
            generate_traininig_data(infile=cov_file,outfile=train_file, row=row, cols=cols, nsims=nsims)
 
        # Run Optimizer
        #train_file = '_'.join(["VERIFAI_RL","FIFO","input",str(num_iter+1)]) +".csv"
        output_file =  '_'.join(["VERIFAI_RL","FIFO","output",str(num_iter+1)]) +".csv"
        print("-------- invoking optimizer with training_data {0}, expected output {1}" .format(train_file, output_file))
        auth = VerifaiAPI(url=args.url)
        resp1 = auth.run_optimize(conf_file, train_file,num_iter+1,incr,output_file)
        print("----run optimizer produced training-data-file {0}" .format(training_data))
        ## Plese make this dynamic and pass in the files required...
        #num_rand_iterations *= 10
        rand_iter_list.append(num_rand_iterations)
        training_data = output_file
        if incr == False:
            incr = True
    auth.plot_histograms('config.json',filename = "combined_actual.png",
                         column=conf_data['Config']['RewardPredictor']['reward_column'],
                         stat = conf_data['Config']['RewardPredictor']['reward_stat'],
                         rand_iter_list = rand_iter_list)


if __name__ == "__main__":

    main(None)
