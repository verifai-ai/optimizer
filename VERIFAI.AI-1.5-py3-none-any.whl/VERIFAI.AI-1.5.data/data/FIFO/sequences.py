#!/bin/env python

# ==============================================================================
# Copyright 2020 VERIFAI Inc All Rights Reserved.
#
# ==============================================================================
'''
#-----------------------------------------------------------------------
#Version: 1.4
#Author(s): Dean Marvin
'''


import sys, os
import svrand

# pick up locally written constraints_define.py
sys.path.append('.')
import constraints_define as const

class seq():
    
    def randomize(self):
        mbus_cmd_array = svrand.logic(11, 0)
        mbus_addr_array = svrand.logic(127, 0)
        mbus_addr_base = svrand.logic(31, 0)

        mbus_cmd_array[2:0] = int(svrand.dist( {
            0b00: const.mbus_cmd_cpu0_NOP_wt,
            0b10: const.mbus_cmd_cpu0_WR_wt,
            0b01: const.mbus_cmd_cpu0_RD_wt,
            0b11: const.mbus_cmd_cpu0_WR_BROAD_wt,
            0b100: const.mbus_cmd_cpu0_RD_BROAD_wt
        }))

        mbus_cmd_array[5:3] = int(svrand.dist( {
            0b00: const.mbus_cmd_cpu1_NOP_wt,
            0b10: const.mbus_cmd_cpu1_WR_wt,
            0b01: const.mbus_cmd_cpu1_RD_wt,
            0b11: const.mbus_cmd_cpu1_WR_BROAD_wt,
            0b100: const.mbus_cmd_cpu1_RD_BROAD_wt
        }))
    
        mbus_cmd_array[8:6] = int(svrand.dist( {
            0b00: const.mbus_cmd_cpu2_NOP_wt,
            0b10: const.mbus_cmd_cpu2_WR_wt,
            0b01: const.mbus_cmd_cpu2_RD_wt,
            0b11: const.mbus_cmd_cpu2_WR_BROAD_wt,
            0b100: const.mbus_cmd_cpu2_RD_BROAD_wt
        }))
    
        mbus_cmd_array[11:9] = int(svrand.dist( {
            0b00: const.mbus_cmd_cpu3_NOP_wt,
            0b10: const.mbus_cmd_cpu3_WR_wt,
            0b01: const.mbus_cmd_cpu3_RD_wt,
            0b11: const.mbus_cmd_cpu3_WR_BROAD_wt,
            0b100: const.mbus_cmd_cpu3_RD_BROAD_wt
        }))

        mbus_addr_array[3:0] =  (mbus_addr_base & 0xF) + const.mbus_addr_cpu0_offset_range;
        mbus_addr_array[15:4] = ((mbus_addr_base & 0xFFF0) >> 4) + const.mbus_addr_cpu0_index_range;
        mbus_addr_array[31:16] = ((mbus_addr_base & 0xFFFF0000) >> 16) + const.mbus_addr_cpu0_tag_range;
        
        mbus_addr_array[32+3:32+0] =  (mbus_addr_base & 0xF) + const.mbus_addr_cpu1_offset_range;
        mbus_addr_array[32+15:32+4] = ((mbus_addr_base & 0xFFF0) >> 4) + const.mbus_addr_cpu1_index_range;
        mbus_addr_array[32+31:32+16] = ((mbus_addr_base & 0xFFFF0000) >> 16)  + const.mbus_addr_cpu1_tag_range;

        mbus_addr_array[64+3:64+0] =  (mbus_addr_base & 0xF) + const.mbus_addr_cpu2_offset_range;
        mbus_addr_array[64+15:64+4] = ((mbus_addr_base & 0xFFF0) >> 4) + const.mbus_addr_cpu2_index_range;
        mbus_addr_array[64+31:64+16] = ((mbus_addr_base & 0xFFFF0000) >> 16) + const.mbus_addr_cpu2_tag_range;

        mbus_addr_array[96+3:96+0] =  (mbus_addr_base & 0xF) + const.mbus_addr_cpu3_offset_range;
        mbus_addr_array[96+15:96+4] = ((mbus_addr_base & 0xFFF0) >> 4) + const.mbus_addr_cpu3_index_range;
        mbus_addr_array[96+31:96+16] = ((mbus_addr_base & 0xFFFF0000) >> 16) + const.mbus_addr_cpu3_tag_range;

        print("        delay 20")
        print("        setNetValue mbus_cmd_array_i 'h{:x}".format(int(mbus_cmd_array)))
        print("        setNetValue mbus_addr_array_i 'h{:x}".format(int(mbus_addr_array)))

def sequences():
    seq1 = seq()
    for j in range(1000):
        seq1.randomize()

if __name__ == "__main__":
    sequences()
