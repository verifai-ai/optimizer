/*
# ==============================================================================
# Copyright 2020 VERIFAI Inc All Rights Reserved.
#
# ==============================================================================
#-----------------------------------------------------------------------
#Version: 1.4
#Author(s): Dean Marvin
*/

#include <verilated.h>          // Defines common routines
#include <verilated_vcd_c.h>
#include <verilated_vpi.h>
#include <iostream>             // Need std::cout
#include <fstream>
#include <string>
#include <sstream>
//#include <bits/stdc++.h>
#include <unistd.h>

#include "Vtop.h"               // From Verilating "top.sv"

using namespace std;

Vtop *top;                      // Instantiation of module
VerilatedVcdC* tfp;

vluint64_t main_time = 0;       // Current simulation time
vluint64_t finish_time = 15000; // default simulation run length

// This is a 64-bit integer to reduce wrap over issues and
// allow modulus.  You can also use a double, if you wish.

double sc_time_stamp () {       // Called by $time in Verilog
    return main_time;           // converts to double, to match
                                // what SystemC does
}

bool setNetValue(string net, string value) {
    string fullName = "TOP.top." + net;
    vpiHandle netHandle = vpi_handle_by_name((PLI_BYTE8*) fullName.c_str(), NULL);
    //cout << vpi_get_str(vpiFullName, net) << endl;
    if(netHandle == NULL) {
        cerr << "Unable to find net " << fullName << endl;
        return false;
    }
    s_vpi_value val;
    size_t tic = value.find("'");
    if(tic == string::npos) {
        val.format = vpiHexStrVal;
        val.value.str = (PLI_BYTE8*) strdup(value.c_str());
    } else {
        char format_char = value[tic+1];
        string subval = value.substr(tic+2);
        val.value.str = (PLI_BYTE8*) strdup(subval.c_str());
        switch (format_char) {
            case 'b': val.format = vpiBinStrVal; break;
            case 'o': val.format = vpiOctStrVal; break;
            case 'd': val.format = vpiHexStrVal; break;
            case 'h': val.format = vpiHexStrVal; break;
            default:  val.format = vpiStringVal; break;
        }
    }
    vpi_put_value(netHandle, &val, NULL, vpiNoDelay);
    free(val.value.str);
    return true;
}

void setFinish(vluint64_t new_finish) {
    finish_time = new_finish;
}

void delay(vluint64_t delay_time) {
    vluint64_t end_time = main_time + delay_time;
    while (!Verilated::gotFinish() && main_time < end_time) {
        if ((main_time % 10) == 5) {
            setNetValue("clk", "1'b1");
        }
        if ((main_time % 10) == 0) {
            setNetValue("clk", "1'b0");
        }
        top->eval();            // Evaluate model
        tfp->dump(main_time);
        main_time++;            // Time passes...
        if (main_time > finish_time) {
            Verilated::gotFinish(true);
        }
    }
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);   // Remember args

    int c;
    string stimFile;
    string vcdFile = "mesi_isc.vcd";
    
    while ((c = getopt(argc, argv, "s:v:")) != -1) {
        switch(c) {
            case 's':
                stimFile = optarg;
                break;
            case 'v':
                vcdFile = optarg;
                break;
            default:
                abort();
        }
    }

    top = new Vtop;             // Create instance
    tfp = new VerilatedVcdC;

    Verilated::traceEverOn(true);
    top->trace(tfp, 0);
    tfp->open(vcdFile.c_str());

    setFinish(20000);
    
    setNetValue("clk", "1'b0");
    setNetValue("rst", "1'b1");
    setNetValue("broad_fifo_status_full_i", "1'b0");
    delay(20);
    setNetValue("rst", "1'b0");

    if( ! stimFile.empty()) {
    string line;
    ifstream stim(stimFile.c_str());
    int count = 0;
    if (stim.is_open()) {
        while(getline(stim, line)) {
            stringstream cmdline(line);
        string cmd;
            while(getline(cmdline, cmd, ' ')) {
                if(cmd.empty()) {
                    continue;
                }
                if (cmd == "delay") {
                    string valstr;
                    getline(cmdline, valstr, ' ');
                    int value = atoi(valstr.c_str());
                    delay(value);
                    ++count;
                } else if(cmd == "setNetValue") {
                    string net, valstr;
                    getline(cmdline, net, ' ');
                    getline(cmdline, valstr, ' ');
                    setNetValue(net, valstr);
                    ++count;
                }
            }
        }
        stim.close();
        cout << "Read " << count << " lines from file " << stimFile << endl;
    } else {
       cout << "Unable to open file " << stimFile << endl;
    }
    }

    delay(finish_time);
    tfp->close();

    top->final();               // Done simulating
    delete top;
}
