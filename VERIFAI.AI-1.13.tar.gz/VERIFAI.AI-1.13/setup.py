# ==============================================================================
# Copyright (c)  2018 VerifAI All Rights Reserved.
#
# ==============================================================================


from setuptools import setup

setup(name='VERIFAI.AI',

      version='1.13',
      description='VerifAI Inc Optimizer Distribution',
      author='VerifAI Inc',
      author_email='hello@verifai.ai',
      url='https://www.verifai.ai',
      install_requires=[
   'requests',
   'pandas',
   'scipy',
   'matplotlib',
   'seaborn'
],
scripts = [ 'signup.py',
             'signin.py',
	    'optimize.py',
        'VerifaiServerAPI.py'
	    ],
    data_files = [("", ["requirements.txt"]),("",["README.md","config.json"]),("FIFO",["FIFO/FIFO.py","FIFO/run_sims.py","FIFO/run_sims_vlt.py","FIFO/run_sims_cdn.py","FIFO/sequences.py","FIFO/svrand.py","FIFO/testbench_vlt.cpp","FIFO/testbench_vlt.sv","FIFO/config.json","FIFO/FIFO.cov_per_config.txt","FIFO/random_knobs.csv","FIFO/mesi_isc_basic_fifo.v","FIFO/mesi_isc_breq_fifos.v","FIFO/mesi_isc_breq_fifos_cntl.v","FIFO/mesi_isc_define.v","FIFO/master.vcs","FIFO/constraints_define.sv","FIFO/design.sv","FIFO/sequences.sv","FIFO/testbench.sv"])]
     )
