''' Authenticate VERIFAI.AI User Signup and allow access to token:
 The token can be used to access the VERIFAI.AI API...
Class VerifaiAuth() handles signup, signin, and other authorizations for the verifai api
'''
# ==============================================================================
# Copyright 2020 Verifai Inc All Rights Reserved.
#
# ==============================================================================
import glob
import requests
import sys
import os.path
from os import path
from pathlib import Path
import json
import uuid
import numpy as np
import pandas as pd
import re
import getpass
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pylab import rcParams
import shutil
import seaborn as sns
import jwt as jwt
import socket
import pwd

sys.path.append(os.path.join(os.path.dirname(__file__), "./"))

#VERIFAI_SERVER_URL='https://api.verifai.ai'
VERIFAI_SERVER_URL='http://localhost:9000'

class VerifaiAPI(object):

   def __init__(self, url=VERIFAI_SERVER_URL):
      self.url = url
      self.token = None
      self.username = None

   def create_temp_token(self):

      ## Hack for WDC
      d = socket.getfqdn()
      if 'wdc.com' in d:
         username = pwd.getpwuid( os.getuid())[0]
         username = username.replace('.','-')
         jwt_sec = 'XCc_UsEbl8:!@vFf_aNz7RmbidB"w|'
         #print("username: {0}" .format(username))
         payload = {"username" : username, "email" : username+'@wdc.com' , "workspace" : "/mlp/verifai.server/"+username}
         #print('payload {0}' .format(payload))
         encoded_token = jwt.encode(payload, jwt_sec, algorithm="HS256")
         #print(encoded_token)
         conf = {}
         conf['token'] = encoded_token
         user = payload
         conf['user'] = user
         return conf
      else:
         return None
   

   def read_settings(self):

      ## The file is called ~/.verifai
      conf = None
      home = str(Path.home())
      self.inzfile = home+'/.verifai'
      if path.exists(self.inzfile):
         with open(self.inzfile) as data_file:
            try:
               conf = json.load(data_file)
            except Exception as e:
               print("Error: {0}" .format(str(e)))
               pass
            try:
               self.token = conf['token']
               self.username = conf['user']['username']
            except:
               pass
            try:
               self.url = conf['url']
            except:
               pass
            
            return conf
      conf = self.create_temp_token()
      if conf is not None:
         #print("conf temp token: {0}" .format(conf))
         return conf
         
      return None


   def save_settings(self, token, user):

      '''
      Save Token In Users' directory
      The file is called ~/.verifai
      '''
      conf = {}
      home = str(Path.home())
      self.inzfile = home+'/.verifai'
      #if path.exists(self.inzfile):


      conf['token'] = token
      conf['user'] = user
      conf['url'] = self.url
      self.token = token
      self.username = user['username']

      with open(self.inzfile, 'w') as json_file:
         json.dump(conf, json_file)

   def signup_session(self):
      #username = input("Please enter a username for VerifAI: ")
      val_email = False
      while not val_email:
          email = input("Please enter a valid email: ")
          val_email = self.check(email)
      pass_match = False

      while not pass_match:
          pswd1 = getpass.getpass("Please Enter your password: ")
          pswd2 = getpass.getpass("Please Re-enter your password: ")
          pass_match = pswd1 == pswd2
          if not pass_match:
              print("Passwords do not match please try again")
      return  email, pswd1

   def signin_session(self):
      email = input("Please enter your email: ")
      pswd = getpass.getpass("Please Enter your password: ")
      return email,pswd

   def check(self,email):
     # pass the regualar expression
    # and the string in search() method
      regex = '^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$'
      if(re.search(regex,email)):
          return True
      else:
          print("Invalid Email please try again:\n")

   def ask_user_continue(self):
      check = str(input("Do you want to try again ? (Y/N): ")).lower().strip()
      try:
        if check[0] == 'y':
            return True
        elif check[0] == 'n':
            return False
        else:
            print('Invalid Input')
            return self.ask_user_continue()
      except Exception as error:
        print("Please enter valid inputs")
        print(error)
        return self.ask_user_continue()

   def signupsignin(self, mode=None, email = None, password = None, username=None):

      sign = self.url + mode
      ## Add your username and password here..
      body = {'email' : email , 'password' : password}

      ## Ldap Input
      # body = {'username' : username , 'password' : password, 'loginType' : 'LDAP'}
      
      ## Call the API:
      print("Connecting to server: {0}" .format(sign))
      x = requests.post(sign , data=body)

      #print('posting url: {0}' .format(sign))
      resp =   x.json()
      #print("Response: {0}" .format(resp))
      if 'error' in resp:
         #print("Error: {0}" .format(resp['error']))
         return resp
      else:
         user = resp['user']
         if not user:
            print("Error: Received unknown response: {0}" .format(user))
            return resp
         try:
            token = resp['token']
            self.save_settings(token,user)
         except Exception as e:
            #print("Couldn't save settings as {}".format(e))
            pass
         return resp
      return resp

   def signup(self, email, password):

      return(self.signupsignin(mode='/api/v2/auth/signup', email = email, password = password))

   def signin(self, email,  password):

      return(self.signupsignin(mode='/api/v2/auth/signin',email=email, password = password))


   def confirm_signup(self, username, email, inputcode):

      sign = self.url + '/api/v2/auth/confirm-signup'
      ## Add your username and password here..
      body = {'username' : username , 'email' : email, 'inputCode' : inputcode  }

      ## Call the API:
      x = requests.post(sign , data=body)

      resp =   x.json()
      #print("Response: {0}" .format(resp))
      if 'error' in resp:
         print("Error: {0}" .format(resp['error']))
         return None
      else:
         user = resp['user']
         if not user:
            print("Error: Received unknown response: {0}" .format(user))
            return None
         try:
            token = resp['token']
            self.save_settings(token,user)
         except:
            print('error: no token received, please contact hello@verifai.ai')
            return None

         return resp
      return None

   def print_copyright(self):
      print('# ==============================================================================')
      print('# Copyright 2020 Verifai Inc All Rights Reserved.')
      print('#')
      print('# Welcome to Verifai Inc Signup')
      print('# Please signup to get your credentials for access to Verifai API')
      print('# ==============================================================================')


   def check_username_password(self):
      if self.token == None:
         conf = self.read_settings()
         if conf == None or conf == {}:
            print("Error: Could not read token and configuration")
            success = False
            attempt = 1
            while not success and attempt <= 3:
               print("Sign in attempt {}".format(attempt))
               email, pswd = self.signin_session()
               conf = self.signin(email,pswd)
               attempt +=1
               if conf is not None and conf != {}:
                  success = True
                  #resp = self.read_settings()
            if not success:
               print("Incorrect login information: Please contact hello@verifai.ai")
               sys.exit()
         self.token = conf['token']
         self.username = conf['user']['username']
         self.email = conf['user']['email']
         #print("Saving User: {0}" .format(conf), file=sys.stderr)
         self.save_settings(conf['token'],conf['user'])


   ## Check JWT Token
   def check_jwt_token(self):

      try:
         status = jwt.decode(token, options={"verify_signature": False})
         return(True, status)
      except Exception as e:
         return(False, str(e))
      
   ## Check Token on Server..

   def check_token(self):

      # Read Token etc..See if it exists
      self.check_username_password()

      #print('checking license with {0}' .format(self.url))
      db = self.url + '/api/v2/auth/check-token'
      headers = {"Authorization": "Bearer " + self.token}
      #print("request: {0}" .format(db))
      resp = requests.post(db, headers=headers)
      data = resp.json()
      status = False
      message = ''
      
      try:
         if data['status'] == 200:
            status = True
         else:
            status = False
         message = data['message']
      except:
         pass
      #print('check-token: {0}' .format(message))
      return (status, message)

   
   ## Get documents from the database

   def get_documents(self, db, collection, outputfilename):

      self.check_username_password()

      db = self.url + '/api/v2/mongo/documents?db='+db+'&collection='+collection
      headers = {"Authorization": "Bearer " + self.token}
      resp = requests.get(db, headers=headers)
      #print("Got Response: {0}" .format(resp))

      data = resp.json()
      with open(outputfilename, 'w') as json_file:
         json.dump(data, json_file)
         print("Saved response in file: {0}" .format(outputfilename))

   ## Run the Optimizer

   def run_optimize(self, config=None, train_file=None, niter=0, incr=False,
                    output_file=None, script="optimize", return_filename=False, rundir=None):

      ## script = { "optimizer" | "run_optimizer"  | "run_pipeline" }
      self.check_username_password()

      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/reward'
      num_rand_iterations = 1000
      with open(config) as fh:
         mydata = fh.read()
         files = {'configFile' : mydata}


      with open(train_file) as fh:
         mydata = fh.read()
         files.update({'trainingFile' : mydata})
      uid = str(uuid.uuid4())
      incv = 0
      if incr:
         incv = 2

      values = {'config_file' : '/config','uuid' : uid, 'exp' : niter, 'incr' : incv, 'script' : script}
      #print("Invoking Optimizer: {0}  Params: {1}" .format(url, values))
      values.update(files)

      # output file names
      head , tail = os.path.splitext(output_file)
      trainingFile = head +'.json'
      csvFileName =  head +'.csv'

      if rundir is not None:
         trainingFile = rundir + '/' + trainingFile
         csvFileName = rundir + '/' + csvFileName
         

      resp = requests.post(url, data=values,headers=headers, stream=True)

      data = resp.json()
      with open(trainingFile, 'w') as fd:
         json.dump(data, fd)

      # Turned off reading in chunks
      '''
      with open(trainingFile, 'wb') as fd:
          for chunk in resp.iter_content(chunk_size=128):
           fd.write(chunk)
     
      with open(trainingFile) as f:
         data = json.load(f)
      '''
      # Close response
      resp.close()

      # Parse Result, Result is stored as {"Result" : [{ 'csv' : [...]}] }
      nres = 0
      results = []
      try:
         results = data['Result']
      except Exception as e:
         print("Couldn't generate result data as {}".format(e))
         #os.remove(self.inzfile)
         pass
      # Write each CSV file..
      csvfiles = []
      for res in results:
         csv = res['csv']
         df = pd.DataFrame(csv)
         # Construct file name..
         head, tail = os.path.splitext(csvFileName)
         if nres == 0:
            csvF = csvFileName
         else:
            csvF = head + '.' + str(nres) + tail
         csvfiles.append(csvF)
         df.to_csv(csvF, index=False)
         #print("Saved file: {0}" .format(csvF))
         nres += 1

      # If return_filename == True, return the csv filename
      if return_filename == True:
         return(csvfiles[0])
      else:
         # Else return json data
         return(data)


   ## Import a CSV or JSON file to the database

   def run_importToDb(self, db=None, collection=None, filename=None, filetype='csv', username=None, gridfs=False, docId=None):

      self.check_username_password()

      ## See if we can invoke importToDb
      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/importToDb'

      with open(filename) as fh:
         mydata = fh.read()
         files = {'file' : mydata}
      args = ""
      if username != None:
         args += " " + "-username " + username
      if gridfs == True:
         args += " " + "-gridfs"

      if docId != None:
         args += " -docid " + docId
         
      args += " -w"

      ## Srtip file name of path..
      filename = os.path.basename(filename)
      
      values = {'db': db, 'collection': collection, 'fileType': filetype,'fileName': filename, 'args' : args}
      
      values.update(files)
      resp = requests.post(url, data=values,headers=headers)
      data = resp.json()
      # Restore stdout and print
      #sys.stdout = sys.__stdout__
      #print("return response from api/importToDb : {0}" .format(data))
      return data


      ## Import a CSV or JSON file to the database

   def send_chat_message(self, channel=None, username=None, message=None):

      self.check_username_password()

      ## See if we can invoke importToDb
      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/chat'

      values = {'channel': channel, 'username': username, 'message': message}
      
      resp = requests.post(url, data=values,headers=headers)
      data = resp.json()
      
      return data

   ## Upload a tar file to the App directory, typically a model_dir , specified by the 'type'
   
   def upload_tar(self, appid=None, apptype="Cluster", dir=None, filename=None, filetype='tgz', username=None):
      '''  Upload a tar file to an app on the server '''
      
      # Endpoint - /api/v2/local/ftp
      # Payload -
      # { appid: "l2pa-regression" , "apptype" <Cluster, Optimizer>, "type" : <model_dir, image_dir>,
      # 
      # 
      # Request Type - POST
      # "dir" : "model_dir",
      # "file" : "blah.tar.gz"
      # filetype : <tgz, csv, json , png>
      
      self.check_username_password()

      ## See if we can invoke importToDb
      headers = {"Authorization": "Bearer " + self.token}  # 'accept': "application/json",     'Content-Type': 'multipart/form-data'}

      # Restore stdout and print
      sys.stdout = sys.__stdout__
      print("params: {0}, {1}, {2}, {3} {4}" .format(appid, apptype, dir, filename, filetype))
      files = {
         'file': (filename, open(filename, 'rb')),
      }
      
      print("after files")
      url = self.url + '/api/v2/local/ftp'

      
      payload = {'appid': appid, 'apptype': apptype, 'filetype': filetype, 'dir' : dir, "username" : username}
      print("URL: {0} payload {1}" .format(url, payload))
      print("files = {0}" .format(files))
      
      resp = requests.post(url, data=payload,headers=headers, files=files)
      print("Response: {0}" .format(resp))
      data = resp.json()
      
      return data



   ## Create application by calling API
   
   def create_app(self, appid=None, apptype="Cluster", description=None, config_file=None, resultid=None, result_filename=None):
      '''  Create an application on the server using this API call '''
      #
      # appType: 'cluster',
      # appid: 'l2pa-regression',
      # description: '',
      # config: {},
      # Endpoint - /api/v2/user-apps/apps
      
      self.check_username_password()

      ## See if we can invoke importToDb
      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json" }

      ## Read Config File
      if not path.exists(config_file):
         return None

      with open(config_file) as f:
         conf_data = json.load(f)
         conf_data = json.dumps(conf_data)
         
      url = self.url + '/api/v2/user-apps/create-app'
      
      payload = {'appid': appid, 'apptype': apptype, 'description' : description , 'config' : conf_data, 'resultid' : resultid, 'result_filename' : result_filename}
      
      resp = requests.post(url, data=payload,headers=headers)
      data = resp.json()
      
      return data
   
   
   

   ## Call Build:
   def run_classifier(self, config, train_file):

      self.check_username_password()

      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/build'

      with open(config) as fh:
         mydata = fh.read()
         files = {'configFile' : mydata}

      with open(train_file) as fh:
         mydata = fh.read()
         files.update({'trainingFile' : mydata})

      uid = str(uuid.uuid4())
      values = {'config_file' : "/config",'uuid' : uid}
      values.update(files)
      resp = requests.post(url, data=values,headers=headers)
      data = resp.json()
      #print("Response {0}" .format(data))
      return data



   
      

   ## Call Analyzer
   def run_analyzer(self, config, train_file):

      self.check_username_password()

      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/analyzeData'

      with open(config) as fh:
         mydata = fh.read()
         files = {'configFile' : mydata}

      with open(train_file) as fh:
         mydata = fh.read()
         files.update({'trainingFile' : mydata})

      uid = str(uuid.uuid4())
      values = {'config_file' : "/config",'uuid' : uid}
      values.update(files)
      resp = requests.post(url, data=values,headers=headers)
      data = resp.json()
      #print("Response {0}" .format(data))

   def compute_histogram_score(self,hdata=None):

      if hdata == None:
         return 0.0
      hist, bin_edges = np.histogram(hdata, bins=16)
    
      wt = [.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8 , 0.9 , 1.0, 1.1, 1.2, 1.3, 1.4, 1.5,1.6]
      sumwt = hist*wt
      score = sumwt.sum()/(len(hdata)/100.0)    ## Normalize by 100 simulations..
      return hist, score 

   def get_histogram_data(self, filename=None, column=None):
    
      try:
         dataframe = pd.read_csv(filename,
                                 compression='infer', index_col=False)
         dataframe['reward_column'] = dataframe[column].mean(axis = 1)
         dataframe.dropna(inplace=True)
         
      except:
         print("could not read datafile {0}" .format(filename))
         return None
    
      hdata =  dataframe['reward_column'].values.tolist()
      hist, score = self.compute_histogram_score(hdata)
    
      print("Histogram  {0}  Sum: {1}" .format(hist, score))
      return hdata , score

   
   def plot_histograms(self,csvfiles=None, config=None,filename=None, column=None, stat = None, iter_list = None, xlabel=None):


      if column == None:
         print("none")
         return False
      list_of_files = []
      #Change output to input for actual vcs run
      if csvfiles != None:
         for csvfile in csvfiles:
            list_of_files.append(csvfile)
      else:
         for csvfile in glob.glob('VERIFAI_RL_FIFO_input*.csv'):
            list_of_files.append(csvfile)
            
      try:
         with open(config) as f:
            conf = json.load(f)
      except:
         print("error: could not open config file {0}" .format(config))
         return False

      try:
         image_dir = conf['Config']['images_dir']
      except:
         print("error: could not open config file {0}" .format(config))
         return False
      datasets = []

      for fl in list_of_files:
         try:
            dataframe = pd.read_csv(fl,
                                    compression='infer', index_col=False)
            dataframe['reward_column'] = dataframe[column].mean(axis = 1)
            dataframe.dropna(inplace=True)
            datasets.append(dataframe)

         except:
            print("error: could not read datafile {0}" .format(fl))
            pass
      try:
          shutil.rmtree(conf_data["Config"]["images_dir"])
      except:
          print("No existing image directory")

      # Setup Plot
      sns.set_context("poster", rc={"font.size":15,"axes.titlesize":15,"axes.labelsize":15})


      fig, axs = plt.subplots(len(datasets), figsize=(12,24))
      #sns.despine(left=True)
      nplots = len(datasets)
      for i,v in enumerate(range(nplots)):
         v = v+1
         print('iteration list {0}' .format(v-1))
         ax1 = plt.subplot(nplots,1,v)
         parameters = {'axes.labelsize': 14,
                       'axes.titlesize': 16}
         plt.rcParams.update(parameters)
         
         if v == 1:
            ax1.set(ylabel='occurrence', xlabel=(xlabel if xlabel else ''), title = "Initial Random Distribution")
         else:
            ax1.set(ylabel='occurrence', xlabel=(xlabel if xlabel else ''), title = "Iteration {0}".format(iter_list[v-1]))
            
         #ax1.set(ylabel='occurrence', xlabel=(xlabel if xlabel else ''), title = "{} iterations".format(iter_list[v-1]))
         #sns.distplot(datasets[i]['reward_column'], ax = ax1)
         hdata =  datasets[i]['reward_column'].values.tolist()
         
         hist, score = self.compute_histogram_score(hdata)
         try:
            ax1.text(0.90,0.95, 'Score= '+ "{:0.2f}".format(score),
                     verticalalignment='top', horizontalalignment='right',
                     transform=ax1.transAxes,
                     color='green', fontsize=18)
         except Exception as e:
            print('could not add text label: {0}' .format(str(e)))

         ax1.hist(datasets[i]['reward_column'], range=[0, 15])

      # If directory doesn't exist: create one..
      #fig.savefig(image_dir+"/combined.png")
      fig.tight_layout()
      fig.savefig(filename)
      print("------Saved results are in: {0}" .format(filename))
      #fig.savefig(os.path.join(image_dir,filename))



      
   ## Call pd_predict
   '''
   1. Call to train model: verifai pd_predict -c fiveclf.json
   2. Call to predict_only verifai pd_predict -pb sldpc_top -s PlaceOptDesign_Enc -n CTSynthesis_Enc -c fiveclf.json -pd predict.csv
   '''
   def run_pd_predict(self, config, block=None, step=None, next_step=None, predict_file=None, rundir=None, mongourl=None, output_file=None):

      self.check_username_password()

      headers = {"Authorization": "Bearer " + self.token, 'accept': "application/json"}
      url = self.url + '/api/v2/exec/pd_predict'

      with open(config) as fh:
         mydata = fh.read()
         files = {'configFile' : mydata}

      uid = str(uuid.uuid4())
      values = {'uuid' : uid}
      if predict_file != None:
         with open(predict_file) as fh:
            mydata = fh.read()
            files.update({'predictFile' : mydata})
         values.update({'block' : block, 'step' : step, 'next_step' : next_step, 'rundir' : rundir, 'mongourl' : mongourl, 'output_file' : output_file})

      if rundir != None and mongourl != None:
         values.update({'block' : block, 'step' : step, 'next_step' : next_step, 'rundir' : rundir, 'mongourl' : mongourl, 'output_file' : output_file})
         
      values.update(files)
      print("Headers : {0}" .format(headers))
      resp = requests.post(url, data=values,headers=headers)
      data = resp.json()
      return data

