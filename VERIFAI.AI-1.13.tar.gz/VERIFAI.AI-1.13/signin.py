# Authenticate VERIFAI.AI User Signup and allow access to token:
#     The token can be used to access the VERIFAI.AI API...
#     Class VerifaiAuth() handles signup, signin, and other authorizations for the verifai api

# ==============================================================================
# Copyright 2020 Verifai Inc All Rights Reserved.
#
# ==============================================================================

import sys,os

try:
    if os.environ['VERIFAI_HOME']:
        sys.path.append(os.path.join(os.path.dirname(__file__), os.environ['VERIFAI_HOME']+"/python"))
        sys.path.append(os.path.join(os.path.dirname(__file__), os.environ['VERIFAI_HOME']+"/python/scripts"))
except:
    os.environ['VERIFAI_HOME'] =  os.path.join(os.path.dirname(__file__),"../")
    os.environ['VERIFAI_HOME'] =  os.path.join(os.path.dirname(__file__),"./")
    pass

import requests
import sys
import os.path
from os import path
from pathlib import Path
import json
import uuid
import pandas as pd
import re
import getpass
try:
    from VerifaiServerAPI import *
except ImportError:
    from verifai.server.VerifaiServerAPI import *





VERIFAI_SERVER_URL='https://api.verifai.ai'


''' Authenticate VERIFAI.AI User Signup and allow access to token:
 The token can be used to access the VERIFAI.AI API...
Class VerifaiAuth() handles signup, signin, and other authorizations for the verifai api
'''
# ==============================================================================
# Copyright 2020 Verifai Inc All Rights Reserved.
#
# ==============================================================================

import requests
import sys
import os.path
from os import path
from pathlib import Path
import json
import uuid
import pandas as pd
import re
import getpass
import argparse


def main(args1):


    parser = argparse.ArgumentParser()
    
    parser.add_argument("-url", "--url", dest="url", default=VERIFAI_SERVER_URL,
                        help="Specify a VerifAI URL Server to connect with (Default=http://localhost:9000)", metavar="STRING")

    
    args, unknown = parser.parse_known_args(args1)

    exit = False
    first=True
    while not exit:
        try:
            auth = VerifaiAPI(url=args.url)

            #print("Auth: {0}" .format(auth.url))
            if first:
                auth.print_copyright()
                first=False
            email, password = auth.signup_session()
            resp = auth.signin(password=password,email=email)
            try:
                if resp['error']:
                   print('error: {0}' .format(resp['error']['message']))
                   sys.exit(-1) 
            except:
                pass
            attempt = 1
            code_success  = True
            while not code_success:
                input_code = input(resp["user"]["message"]+": ")
                resp2 = auth.confirm_signup(username= username,email=email,inputcode=str(input_code))
                if resp2 is not None:
                    code_success = True
                elif attempt == 3:
                    print("Run out of attempts aborting...")
                    sys.exit()
                else:
                    print("Attempt {} out of 3, please try again".format(attempt))
                    attempt += 1
                    #print('Resp: {0}' .format(resp))
                    ## Now Signin..
            if code_success == True:
                resp = auth.signin(email,password)
                print('# ==============================================================================')
                print("# Thanks for signing up, your token is stored in ~/.verifai")
                print('# For support please mail hello@verifai.ai')
                print('# ==============================================================================')


            exit = True
        except Exception as e:
            #print("Error is {}".format(e))
            print("Something went wrong...\n")
            reply = auth.ask_user_continue()
            if reply == True:
                pass
            elif reply == False:
                print('# Please try again at a later time or contact hello@verifai.ai for support.')
                exit = True

if __name__ == "__main__":
    import sys
    main(sys.argv[1:])
