#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ==============================================================================
# Copyright 2020 VERIFAI Inc All Rights Reserved.
#
# ==============================================================================
'''
#-----------------------------------------------------------------------
#Version: 1.4
#Author(s): Dean Marvin
Created on Mon Dec 21 14:15:44 2020

@author: dean marvin
'''

import random

class logic(object):
    def __init__(self, start, stop):
        self._start = start
        self._stop = stop
        self._index_dir = 1 if stop >= start else -1
        self._len = abs(start-stop)+1
        self._max_value = 2**(self._len)
        self.randomize()
    
    def __int__(self):
        return self._value
    
    def __str__(self):
        return hex(self._value)
    
    def __repr__(self):
        return "logic({})".format(hex(self._value))
    
    def randomize(self):
        self._value = random.randrange(self._max_value)
        return self._value
    
    def get_value(self):
        return self._value
    
    def set_value(self, value):
        self._value = value
        return self._value

    def range(self):
        return (self._start, self._stop, self._index_dir)
    
    def __len__(self):
        return self._len
    
    def __and__(self, other):
        return self._value & other
    
    def __or__(self, other):
        return self._value | other
    
    def __invert__(self):
        return ~self._value;
    
    def __xor__(self, other):
        return self._value ^ other
    
    def __getitem__(self, key):
        if isinstance(key, slice):
            local_dir = 1 if key.stop >= key.start else -1
            if local_dir == self._index_dir:
                shift = abs(key.stop - self._stop)
                mask = 2**(abs(key.start-key.stop)+1)-1
                return (self._value >> shift) & mask
            else:
                value = 0
                for i in range(key.start, key.stop+local_dir, local_dir):
                    value = (value << 1) | self[i]
                return value
        elif isinstance(key, int):
            shift = abs(key-self._stop)
            return (self._value >> shift) & 1
        else:
            raise TypeError("Invalid argument type.")
        
    def __setitem__(self, key, newvalue):
        if isinstance(key, slice):
            local_dir = 1 if key.stop >= key.start else -1
            if local_dir == self._index_dir:
                shift = abs(key.stop - self._stop)
                mask = 2**(abs(key.start-key.stop)+1)-1
                newvalue = (newvalue & mask) << shift
                oldvalue = ~(mask << shift) & self._value
                self._value = oldvalue | newvalue
            else:
                value = newvalue
                for i in range(key.stop, key.start-local_dir, -local_dir):
                    self[i] = value & 1
                    value = value >> 1
        elif isinstance(key, int):
            shift = abs(key-self._stop)
            oldvalue = ~(1 << shift) & self._value
            newvalue = (newvalue & 1) << shift
            self._value = newvalue | oldvalue
        else:
            raise TypeError("Invalid argument type.")
        
class dist(object):
    def __init__(self, dist_dict):
        self._values = list(dist_dict.keys())
        self._dist = list(dist_dict.values())
        self.randomize()
    
    def randomize(self):
        self._value = random.choices(population=self._values, weights=self._dist, k=1)[0]
        return self._value
    
    def __int__(self):
        return self._value
    
    def __str__(self):
        return hex(self._value)
    
    def __repr__(self):
        return "dist({})".format(hex(self._value))

if __name__ == "__main__":
    random.seed(42)
    x = logic(15, 0)
    print(x.range())
    print(len(x))
    print(x)
    print(hex(x[15:8]))
    print(hex(x[8:15]))
    x[7:0] = 0x5a
    print(x)
    x[0:7] = 0x41
    print(x)
    print(hex(int(x)&0xff))
    
    # test a 25%, 50%, 10%, 15% distribution
    y = dist({1: 25, 2:50, 3:10, 4:15})
    
    count = {}
    for i in range(10000):
        j = y.randomize()
        try:
            count[j] += 1
        except:
            count[j] = 1
    
    for i in sorted(count.keys()):
        print("{}: {}".format(i, count[i]))
    
