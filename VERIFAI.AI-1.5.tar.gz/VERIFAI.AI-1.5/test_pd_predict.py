
''' Authenticate VERIFAI.AI User Signup and allow access to token:
 The token can be used to access the VERIFAI.AI API...
Class VerifaiAuth() handles signup, signin, and other authorizations for the verifai api
'''
# ==============================================================================
# Copyright 2020 Verifai Inc All Rights Reserved.
#
# ==============================================================================

import requests
import sys
import os.path
from os import path
from pathlib import Path
import json
import uuid
import pandas as pd
import re
import getpass
from VerifaiAPI import *
import argparse

VERIFAI_LOCAL_URL='http://localhost:9000'



import sys
import time

def spinning_cursor():
    while True:
        for cursor in '|/-\\':
            yield cursor


def main(args1):


    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", dest="config_file",
                        help="Path to config filename", metavar="STRING")
    # make predict_only bool; use predict_data to override config
    parser.add_argument("-u","--uid", dest="uid", help="Unique ID for Job", metavar="STRING")
    parser.add_argument("-pd","--predict_data", dest="predict_data", help = "Path to predict data file in CSV format" , metavar="STRING")
    parser.add_argument("-o","--output", dest="output_file", help = "Specify an output file" , metavar="STRING")
    
    parser.add_argument("-pb","--predict_block", dest='pred_block',  help = "Specify prediction block" , default=None,metavar="STRING")
    parser.add_argument("-s","--step", dest="pred_step",  help = "Specify prediction base step" , default=None,metavar="STRING")
    parser.add_argument("-n","--next_step", dest="pred_next_step",  help = "Specify prediction future step" , default=None,metavar="STRING")

    parser.add_argument("-r","--rundir", dest="rundir", help = "Specify this argument to set run dir of new prediction file",metavar="STRING")
    parser.add_argument("-m","--mongo", dest="mongourl", help = "Specify this argument to set the mongo url corresponding to the database to obtain prediction data from",metavar="STRING")


    parser.add_argument("-url", "--url", dest="url", default=VERIFAI_SERVER_URL,
                        help="Specify a VerifAI URL Server to connect with (Default=http://localhost:9000)", metavar="STRING")
    args, unknown = parser.parse_known_args(args1)

    if not args.config_file:
        print("Please specify a config file")
        sys.exit(0)

    if args.config_file:
        conf_file = args.config_file
    elif args.folder_name:
        conf_file = args.folder_name + '/config.json'
    else:
        print("Please specify a config file")
        sys.exit(0)


    auth = VerifaiAPI(url=args.url)

    spinner = spinning_cursor()
    for _ in range(50):
        sys.stdout.write(next(spinner))
        sys.stdout.flush()
        time.sleep(0.1)
        sys.stdout.write('\b')
    resp1 = auth.run_pd_predict(conf_file, block=args.pred_block, step=args.pred_step, next_step=args.pred_next_step , predict_file=args.predict_data,
                                rundir=args.rundir, mongourl=args.mongourl, output_file=args.output_file)
    with open('predict.json', 'w') as json_file:
         json.dump(resp1, json_file)
    print("Response: {0}" .format(resp1))
    


if __name__ == "__main__":
    import sys
    main(sys.argv[1:])
