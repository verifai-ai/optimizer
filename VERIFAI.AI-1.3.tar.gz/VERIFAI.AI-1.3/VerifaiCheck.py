
''' Authenticate VERIFAI.AI User Signup and allow access to token:
 The token can be used to access the VERIFAI.AI API...
Class VerifaiAuth() handles signup, signin, and other authorizations for the verifai api
'''
# ==============================================================================
# Copyright 2020 Verifai Inc All Rights Reserved.
#
# ==============================================================================

import requests
import sys
import os.path
from os import path
from pathlib import Path

import sys,os
sys.path.append(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(os.path.join(os.path.dirname(__file__), "./"))


import json
import uuid
import pandas as pd
import re
import getpass
from .VerifaiAPI import *
import argparse
import socket

def VerifaiCheckToken():

    status = False

    ## Hack for WDC
    d = socket.getfqdn()
    if 'wdc.com' in d:
        #log.info("VerifAI is running on {0}" .format(d))
        return True
        
    try:
        auth = VerifaiAPI()
        status, message = auth.check_token()
        
    except Exception as e:
        VerifaiErrorMsg("could not check license", str(e))
        sys.exit(0)
        #return status , message
        
    if status == False:
        VerifaiErrorMsg("could not validate license")
        sys.exit(0)

    return status


def VerifaiErrorMsg(logmsg=None, errmsg=None):

    print('# ==============================================================================')


    if logmsg == None:
        print("# error: {0}\n1. Check to see if your license exists ~/.verifai\n2. Signup for VerifAI: use \'verifai signup\'\n3. Please contact hello@verifai.ai" .format(logmsg))
    else:
        if errmsg:
            print("# error:{0}: {1}\n1. Check to see if your license exists ~/.verifai\n2. Signup for VerifAI: use \'verifai signup\'\n3. Please contact hello@verifai.ai"
                      .format(logmsg,errmsg))
        else:
            print("# error {0}\n1. Check to see if your license exists ~/.verifai\n2. Signup for VerifAI: use \'verifai signup\'\n3. Please contact hello@verifai.ai" .format(logmsg))

    print('# Copyright 2020 Verifai Inc All Rights Reserved.')
    print('# ==============================================================================')
