# ==============================================================================
# Copyright (c)  2018 VerifAI All Rights Reserved.
#
# ==============================================================================


from setuptools import setup

setup(name='VERIFAI.AI',

      version='1.3',
      description='VERIFAI.AI Optimizer Distribution',
      author='VERIFAI.AI',
      author_email='dev@VerifAI',
      url='http://www.VerifAI',
      install_requires=[
   'requests',
   'pandas',
   'scipy',
   'matplotlib',
   'seaborn'
],
scripts = [ 'signup.py',
	    'optimize.py',
        'VerifaiAPI.py'
	    ],
    data_files = [("", ["requirements.txt"]),("", ["config.json"]),("", ["FIFO_knobs.csv"]),("",["README.html"]),("",["README.md"]),("example",["example/run_sims.py","example/config.json","example/FIFO.cov_per_config.txt","example/random_knobs.csv","example/mesi_isc_basic_fifo.v","example/mesi_isc_breq_fifos.v","example/mesi_isc_breq_fifos_cntl.v","example/mesi_isc_define.v","example/master.vcs","example/constraints_define.sv","example/design.sv","example/sequences.sv","example/testbench.sv"]),("images", ["images/FIFO-RL-Img1.png","images/FIFO-RL-Img2.png","images/FIFO-RL-Img3.png","images/FIFO-RL-Img4.png","images/image33.png","images/image34.png","images/image57.png","images/image59.png"])]
     )
